$(document).ready(function(){
    $('.menu').click(function() {
        $('ul').toggleClass('active')
    })


)}